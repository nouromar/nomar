import io
import os

from setuptools import setup, find_packages


def read_file(fname, encoding='utf-8'):
    path = os.path.join(os.path.dirname(__file__), fname)
    return io.open(path, encoding=encoding).read()
setup(
    name='vzta',
    version='1.0',
    description='Text Analytics and Machine Learning, Voice of the Customers',
    author='Nour Omar',
    author_email='nour2005@gmail.com',
    classifiers = [
        'Development Status :: 5 - Production',
        'Programming Language :: Python',
        'Programming Language :: Python :: 2.7',
        ],
    keywords = 'vzta, spacy, nlp, text processing, linguistics, machine learning',

    packages=find_packages(),
    install_requires=[
    # all packages required here....
        ],
)
