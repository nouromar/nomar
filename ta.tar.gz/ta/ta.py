#__author__ = "Nour Omar"
#__version__ = "1.0"
#__email__ = "nour.omar@verizon.com"
#__status__ = "Production"

import ConfigParser
import argparse
import os
from os.path import join
from vzta.algorithms import ngramAnalysis,DA, topic_model
import logging
from datetime import datetime


import sys
reload(sys)
sys.setdefaultencoding('utf-8')

logdir = "log"
logfile = "log_" + datetime.now().strftime("%Y%m%d") + ".log"

if not os.path.exists(logdir):
    os.makedirs(logdir)

logging.basicConfig(filename=join(logdir, logfile), format='%(asctime)s - %(name)s - %(message)s',
	level=logging.INFO)
logger = logging.getLogger(__name__)
algorithms = {
    'descriminant': DA,
    'ngramAnalysis': ngramAnalysis,
    'topics': topic_model,
    }


def getConfigSections(config):
    sects = config.sections()
    empty = True
    sections = []
    algNames = algorithms.keys()
    for n in algorithms:
        if n in sects:
            sections.append(n)
            empty = False
    if empty:
        raise Exception("no configuration section defined for any of the algorithms({})".format(
            ','.join(algorithms.keys())))
    return sections


def processSection(config, sectionName):
    #print(config.items(sectionName))
    alg = algorithms[sectionName]
    alg(config, sectionName)

parser = argparse.ArgumentParser()

parser.add_argument(
    '-c', "--config", help="please provide configuration file name. If file is not in the same directory as this program, provide full path.")

args = parser.parse_args()
if not os.path.exists(args.config):
    raise Exception(args.config + " does not exist")

config = ConfigParser.ConfigParser()
config.read(args.config)
#logger.info(str(config))

sections = getConfigSections(config)

# algorithm = algorithms[name]
# algorithm(section)


for section in sections:
    #msg = "running algorithm:" + section
    #print(msg)
    #logger.info(msg)
    processSection(config, section)
