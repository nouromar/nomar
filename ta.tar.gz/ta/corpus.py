#__author__ = "Nour Omar"
#__version__ = "1.0"
#__email__ = "nour.omar@verizon.com"
#__status__ = "Production"
import os
import pandas as pd
import csv
import numbers
from util import getOpt
from os import listdir
from os.path import isfile, join
import logging
logger = logging.getLogger(__name__)
import ntpath


def fromExcel(filename, text_col=0):
    docFrame = pd.read_excel(filename)
    if not isinstance(text_col, numbers.Number) and not isinstance(text_col, (str, unicode)):
        raise ValueError(
            'text_col has to be either integer index or column name(string)!')
    for i, r in docFrame.iterrows():
        text = r[text_col]
        if isinstance(text, (str, unicode)) and len(text) > 0:
            text = text.decode('utf-8').strip()
            if text:
                doc = getDoc(text)
                yield doc


def fromText(filename, delimiter=',', text_col=0, has_header=True, quoting=csv.QUOTE_NONE):
    inFile = open(filename)
    text_col_index = 0
    inFile = open(filename, 'rb')
    csv_reader = csv.reader(inFile, delimiter=delimiter, quoting=quoting)

    headers = []
    if has_header:
        headers = csv_reader.next()
    if isinstance(text_col, numbers.Number):
        text_col_index = text_col
    elif isinstance(text_col, (str, unicode)) and has_header:
        text_col_index = headers.index(text_col)
    else:
        raise ValueError(
            'text_col has to be either integer index or column name(string)!')
    for r in csv_reader:
        if len(r) > 0:
            text = r[text_col_index]
            if isinstance(text, (str, unicode)) and len(text) > 0:
                #text = text.encode('utf-8').strip()
                if text:
                    yield text
    inFile.close()


class Corpus(object):

    def __init__(self, path, has_header=True, delimiter=',', text_col=0):

        self.input_path = path
        self.has_header = has_header
        self.delimiter = delimiter
        self.text_col = text_col
        self.corpuses = []
        print(self.input_path)
        if not os.path.exists(self.input_path):
            raise Exception(self.input_path + " does not exist")

        if not isfile(self.input_path):
            self.files = [f for f in listdir(self.input_path) if isfile(join(self.input_path, f))]
            for f in self.files:
                corpus = fromText(join(self.input_path, f), delimiter=self.delimiter,
                                  text_col=self.text_col)
                self.corpuses.append(corpus)
        else:
            self.files = [self.input_path]
            corpus = fromText(self.input_path, delimiter=self.delimiter, text_col=self.text_col)
            self.corpuses.append(corpus)

     


        self.n_corpus = len(self.corpuses)

    def __repr__(self):
        return 'Corpuses(path={}; # of files={}; has_header={}, delimiter={},text_col={})'.format(self.input_path, len(self.files), self.has_header, self.delimiter, self.text_col)

    def __len__(self):
        return len(self.corpuses)

    def __getitem__(self, index):
        return self.corpuses[index]

    def __delitem__(self, index):
        del self.corpuses[index]

    def __iter__(self):
        for corpus in self.corpuses:
            yield corpus

    def getFileNames(self):
        if isfile(self.input_path):
            return [ntpath.basename(self.input_path)]
        return self.files
