#__author__ = "Nour Omar"
#__version__ = "1.0"
#__email__ = "nour.omar@verizon.com"
#__status__ = "Production"
from __future__ import absolute_import, division, print_function, unicode_literals
import collections
import itertools
import operator
import pandas as pd
from pandas import ExcelWriter
from datetime import datetime
from os.path import splitext, join
import numpy as np
import scipy.sparse as sp
from sklearn.preprocessing import binarize as binarize_mat
from sklearn.preprocessing import normalize as normalize_mat
from spacy.strings import StringStore
from sklearn.feature_extraction.text import CountVectorizer


def save_xls(list_dfs, names, xls_path, index=True):
    writer = ExcelWriter(xls_path)
    for n, df in enumerate(list_dfs):
        df.to_excel(writer, names[n], index=index)
    writer.save()


def tryGet(conf, section, name, typ='str'):
    try:
        if typ == 'str':
            return conf.get(section, name)
        if typ == 'int':
            return conf.getInt(section, name)
        if typ == 'float':
            return conf.getFloat(section, name)
        if typ == 'bool':
            return conf.getBoolean(section, name)
    except:
        return None


def getOpt(conf, section, name, default=None, typ='str'):
    val = tryGet(conf, section, name, typ)
    if val is None and not default is None:
        return default
    return val


def makeFilename(output_dir,file_prefix, ext='xlsx'):
    if file_prefix and len(file_prefix)>0:
        filename= file_prefix + "-" + datetime.now().strftime("%Y%m%d%H%M%S") + "." + ext
    else:
        filename= datetime.now().strftime("%Y%m%d%H%M") + "." + ext
    return join(output_dir,filename)


def getSheetNames(names):
    sheets = [splitext(s)[0][:29] + str(i) for i, s in enumerate(names)]
    return sheets



def topTerms(matrix, id2term, n=100, cols=[]):
    ids = range(len(id2term))
    ts = {id2term[i]: matrix[:, i].sum(axis=0)[0, 0] for i in ids}
    sorted_ts = sorted(
        ts.iteritems(), key=operator.itemgetter(1), reverse=True)[:n]
    if cols:
        colnames = cols
    else:
        colnames = ['Terms', 'Count']
    return pd.DataFrame([(t[0], t[1]) for t in sorted_ts], columns=colnames)







def get_doc_freqs(doc_term_matrix, normalized=True):
    if doc_term_matrix.nnz == 0:
        raise ValueError('term-document matrix must have at least 1 non-zero entry')
    n_docs, n_terms = doc_term_matrix.shape
    dfs = np.bincount(doc_term_matrix.indices, minlength=n_terms)
    
    if normalized is True:
        return dfs / n_docs
    else:
        return dfs




def calculate_likelyhood(df1,n_doc1,df2,n_doc2):
    #rf1 = float(df1) / n_doc1  # bigger one
    diff = df1-df2
    return diff/float(n_doc1)


def da_vectorizer(terms_list):
    def my_analyzer(doc):
        return [t for t in doc]
    vectorizer = CountVectorizer(analyzer=my_analyzer,  min_df=2, max_df=0.95)
    dtm = vectorizer.fit_transform(terms_list)
    return (dtm,vectorizer.get_feature_names())
