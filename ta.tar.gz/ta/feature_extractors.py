#__author__ = "Nour Omar"
#__version__ = "1.0"
#__email__ = "nour.omar@verizon.com"
#__status__ = "Production"

from spacy.tokens.token import Token as spacy_token
from spacy.tokens.span import Span as spacy_span
from cytoolz import itertoolz
from itertools import takewhile
import logging
from nlp import getDoc
from util import *
logger = logging.getLogger(__name__)


SUBJECTS = ["nsubj", "nsubjpass", "csubj", "csubjpass", "agent", "expl"]
OBJECTS = ["dobj", "dative", "attr", "oprd", 'pobj']


class OVR(object):
    ALL = 1
    FIRST = 2
    LAST = 3
    COMBINED = 4


def _get_conjuncts(tok):
    """
    Return conjunct dependents of the leftmost conjunct in a coordinated phrase,
    e.g. "Burton, [Dan], and [Josh] ...".
    """
    return [right for right in tok.rights
            if right.dep_ == 'conj']


def get_objects_of_verb(verb):
    """
    Return all objects of a verb according to the dependency parse,
    including open clausal complements.
    """
    objs = [tok for tok in verb.rights
            if tok.dep_ in OBJECTS]
    # get open clausal complements (xcomp)
    objs.extend(tok for tok in verb.rights
                if tok.dep_ == 'xcomp')
    # get additional conjunct objects
    objs.extend(tok for obj in objs for tok in _get_conjuncts(obj))
    return objs


def get_main_verbs_of_sent(sent):
    """Return the main (non-auxiliary) verbs in a sentence."""
    return [tok for tok in sent
            if tok.pos_ == 'VERB' and tok.dep_ not in {'aux', 'auxpass'}]


def getSubsFromConjunctions(subs):
    moreSubs = []
    for sub in subs:
        # rights is a generator
        rights = list(sub.rights)
        rightDeps = {tok.lower_ for tok in rights}
        if "and" in rightDeps:
            moreSubs.extend(
                [tok for tok in rights if tok.dep_ in SUBJECTS or tok.pos_ == "NOUN"])
            if len(moreSubs) > 0:
                moreSubs.extend(getSubsFromConjunctions(moreSubs))
    return moreSubs


def getObjsFromConjunctions(objs):
    moreObjs = []
    for obj in objs:
        # rights is a generator
        rights = list(obj.rights)
        rightDeps = {tok.lower_ for tok in rights}
        if "and" in rightDeps:
            moreObjs.extend(
                [tok for tok in rights if tok.dep_ in OBJECTS or tok.pos_ == "NOUN"])
            if len(moreObjs) > 0:
                moreObjs.extend(getObjsFromConjunctions(moreObjs))
    return moreObjs


def getVerbsFromConjunctions(verbs):
    moreVerbs = []
    for verb in verbs:
        rightDeps = {tok.lower_ for tok in verb.rights}
        if "and" in rightDeps:
            moreVerbs.extend(
                [tok for tok in verb.rights if tok.pos_ == "VERB"])
            if len(moreVerbs) > 0:
                moreVerbs.extend(getVerbsFromConjunctions(moreVerbs))
    return moreVerbs


def findSubs(tok):
    head = tok.head
    while head.pos_ != "VERB" and head.pos_ != "NOUN" and head.head != head:
        head = head.head
    if head.pos_ == "VERB":
        subs = [tok for tok in head.lefts if tok.dep_ == "SUB"]
        if len(subs) > 0:
            verbNegated = isNegated(head)
            subs.extend(getSubsFromConjunctions(subs))
            return subs, verbNegated
        elif head.head != head:
            return findSubs(head)
    elif head.pos_ == "NOUN":
        return [head], isNegated(tok)
    return [], False


def isNegated(tok):
    negations = {"no", "not", "n't", "never", "none", 'nt'}
    for dep in list(tok.lefts) + list(tok.rights):
        if dep.lower_ in negations:
            return True
    return False


def getObjsFromPrepositions(deps):
    objs = []
    for dep in deps:
        if dep.pos_ == "ADP" and dep.dep_ == "prep":
            objs.extend(
                [tok for tok in dep.rights if tok.dep_ in OBJECTS or tok.pos_ == "PRON"])
    return objs


def getObjFromXComp(deps):
    for dep in deps:
        if dep.pos_ == "VERB" and dep.dep_ == "xcomp":
            v = dep
            rights = list(v.rights)
            objs = [tok for tok in rights if tok.dep_ in OBJECTS]
            objs.extend(getObjsFromPrepositions(rights))
            if len(objs) > 0:
                return v, objs
    return None, None


def get_span_for_noun(noun, doc):
    min_i = noun.i - sum(1 for _ in takewhile(lambda x: x.dep_ in ['compound', 'amod'],
                                              reversed(list(noun.lefts))))
    return doc[min_i:noun.i + 1]


def getSubjsFromHead(v):
    if v.dep_ == u'xcomp' and v.head != v:
        return get_subjects_of_verb(v.head)
    return []


def getAcomp(v):
    if v.lemma_ == 'be':
        for c in v.rights:
            if c.pos_ == 'VERB' and c.dep_ == 'acomp':
                return c
    return v


def getAllSubs(v, doc):
    verbNegated = isNegated(v)
    subs = [tok for tok in v.lefts if tok.dep_ in SUBJECTS and tok.pos_ != "DET"]
    if len(subs) > 0:
        subs.extend(getSubsFromConjunctions(subs))
    else:
        foundSubs, verbNegated = findSubs(v)
        subs.extend(foundSubs)
    return subs, verbNegated, getAcomp(v)


def expandObjs(objs):
    result = []
    for n in objs:
        result.append(n)
        result.extend(getObjsFromPrepositions(n.rights))
    return result


def SVO(doc):
    sents = doc.sents
    result = []
    processedVerbs = []
    for s in sents:
        verbs = get_main_verbs_of_sent(s)
        for v in verbs:
            if v in processedVerbs:
                continue
            Vs = [v]
            subs, negated, v2 = getAllSubs(v, doc)
            if v2 != v:
                processedVerbs.append(v2)
                Vs.append(v2)

            objs = get_objects_of_verb(v)
            objs.extend(getObjsFromPrepositions(v.rights))
            objs = expandObjs(objs)

            objs = [get_span_for_noun(o, doc) if o.pos_ != 'VERB' else doc[
                o.i:o.i + 1] for o in objs]
            subs = [get_span_for_noun(s, doc) if s.pos_ != 'VERB' else doc[
                s.i:s.i + 1] for s in subs]
            result.append([subs, negated, Vs, objs])
    return result


def selectSubs(subs, sub_filter=['PRON']):
    goodSubs = []
    for s in subs:
        for t in s:
            if not t.pos_ in sub_filter:
                if t.text.upper() != 'I':
                    goodSubs.append(t)
    if goodSubs:
        return ' ' .join([g.text for g in goodSubs])
    return ''


def selectVerbs(negated, verbs, verb_filter=[]):
    if verbs:
        if negated:
            v = verbs[-1]
            if v.lemma_ == 'be':
                return '(not)' + v.text
            else:
                return v.text + '(not)'
        else:
            return verbs[-1].text
    return ''


def selectObjs(objs, obj_filter=['VERB']):
    goodObjs = []
    for o in objs:
        for t in o:
            if not t.pos_ in obj_filter:
                goodObjs.append(t.text)
    if goodObjs:
        return ' ' .join(goodObjs)
    return ''


def VSOTerms(doc, sub_filter=['PRON'], verb_filter=[], obj_filter=['VERB']):
    terms = []
    vsos = SVO(doc)
    for e in vsos:
        sub = selectSubs(e[0], sub_filter=sub_filter)
        vb = selectVerbs(e[1], e[2], verb_filter=verb_filter)
        ob = selectObjs(e[3], obj_filter=obj_filter)
        if any([sub, ob]):
            term = sub + ' ' + vb + ' ' + ob
            terms.append(term.strip())
    return terms


ignore_words = ["ok", "thank", "thanks", "yes", "oh", "great", "hi", "hello",
                "'m", "'s", "'ll", "'ve", "okay", "'d",
                "'re", "ass", "lol", "think", 'ill', 'like',
                'sorry', 've', 'guys', 'wo', 'yeah', 'right', 'ca', 'jessica', 'mike', 'amy']


def normalized_str(token):

    if isinstance(token, spacy_token):
        return token.text if preserve_case(token) else token.lemma_
    elif isinstance(token, spacy_span):
        return ' '.join(subtok.text if preserve_case(subtok) else subtok.lemma_
                        for subtok in token)
    else:
        msg = 'Input must be a spacy Token or Span, not {}.'.format(
            type(token))
        raise TypeError(msg)


def ngrams(doc, n,
           filter_stops=True, filter_punct=True, filter_nums=False,
           include_pos_tags=None, exclude_pos_tags=None, min_freq=1, ovr=OVR.ALL):

    if n < 1:
        raise ValueError('n must be greater than or equal to 1')

    ngrams_ = [doc[i: i + n]
               for i in range(len(doc) - n + 1)]
    ngrams_ = [ngram for ngram in ngrams_
               if not any(w.is_space for w in ngram)]
    if filter_stops is True:
        ngrams_ = (ngram for ngram in ngrams_
                   if not is_stop(ngram, n))
                   # if not ngram[0].is_stop and not ngram[-1].is_stop)

    if filter_punct is True:
        ngrams_ = [ngram for ngram in ngrams_
                   # if not isPunct(ngram))
                   if not any(w.is_punct for w in ngram)]

    if filter_nums is True:
        ngrams_ = [ngram for ngram in ngrams_
                   if not any(w.like_num for w in ngram)]
    if include_pos_tags:
        ngrams_ = [ngram for ngram in ngrams_
                   if all(w.pos_ in include_pos_tags for w in ngram)]
    if exclude_pos_tags:
        ngrams_ = [ngram for ngram in ngrams_
                   if not any(w.pos_ in exclude_pos_tags for w in ngram)]

    ngrams_ = handleOVR(doc, ngrams_, ovr)
    return ngrams_


def words(doc,
          filter_stops=True, filter_punct=True, filter_nums=False,
          include_pos_tags=None, exclude_pos_tags=None, min_freq=1):

    words_ = (w for w in doc if not w.is_space)
    if filter_stops is True:
        words_ = (
            w for w in words_ if not w.is_stop and not w.text.lower() in ignore_words)
    if filter_punct is True:
        words_ = (w for w in words_ if not w.is_punct)
    if filter_nums is True:
        words_ = (w for w in words_ if not w.like_num)
    if include_pos_tags:
        words_ = (w for w in words_ if w.pos_ in include_pos_tags)
    if exclude_pos_tags:
        words_ = (w for w in words_ if w.pos_ not in exclude_pos_tags)
    if min_freq > 1:
        words_ = list(words_)
        freqs = itertoolz.frequencies(normalized_str(w) for w in words_)
        words_ = (w for w in words_
                  if freqs[normalized_str(w)] >= min_freq)

    for word in words_:
        yield word


def is_stop(ngram, n):
    return len([i for i in ngram if i.is_stop or i.text.lower() in ignore_words]) > 1


def ngram_extractor(txt, n, filter_stops=True, filter_punct=True,
                    filter_nums=False, include_pos_tags=None, exclude_pos_tags=None, min_freq=1,ovr=OVR.ALL):
    doc = getDoc(txt)
    grams = ngrams(doc, n, filter_stops=filter_stops, filter_punct=filter_punct, filter_nums=filter_nums,
                   include_pos_tags=include_pos_tags, exclude_pos_tags=exclude_pos_tags, min_freq=min_freq,ovr=ovr)
    return [' '.join([n.lemma_ for n in ng]) for ng in grams]


def word_extractor(txt, filter_stops=True, filter_punct=True,
                   filter_nums=False, include_pos_tags=None, exclude_pos_tags=None, min_freq=1):
    doc = getDoc(txt)
    ws = words(doc,  filter_stops=filter_stops, filter_punct=filter_punct, filter_nums=filter_nums,
               include_pos_tags=include_pos_tags, exclude_pos_tags=exclude_pos_tags, min_freq=min_freq)
    return [w.lemma_.lower() for w in ws]



def concat_extractor(txt, filter_stops=True, filter_punct=True,
                   filter_nums=False, include_pos_tags=None, exclude_pos_tags=None, min_freq=1):
    doc = getDoc(txt)
    ws = words(doc,  filter_stops=filter_stops, filter_punct=filter_punct, filter_nums=filter_nums,
               include_pos_tags=include_pos_tags, exclude_pos_tags=exclude_pos_tags, min_freq=min_freq)
    return [ ' '.join([w.lemma_.lower() for w in ws])]


def makeExtractor(config, section):
    sectionName = config.get(section, 'extractor')
    if not sectionName:
        raise Exception(" extractor needs to be defined in [" + section + "]")

    etype = getOpt(config, sectionName, 'extractor_type', default='ngram')

    if not etype:
        raise Exception(
            " extractor_type needs to be defined in [" + sectionName + "]")

    if etype not in ('ngram', 'words'):
        raise Exception(
            "For now, only ngram and word is currently supported for extractor_type")

    if etype == 'ngram':
        n = getOpt(config, sectionName, 'n', default=3, typ='int')
        filter_stops = getOpt(config, sectionName,
                              'filter_stops', default=True, typ='bool')
        filter_punct = getOpt(config, sectionName,
                              'filter_punct', default=True, typ='bool')
        filter_nums = getOpt(config, sectionName,
                             'filter_punct', default=False, typ='bool')
        return lambda d: ngram_extractor(d, n, filter_stops=filter_stops, filter_punct=filter_punct, filter_nums=filter_nums)
    if etype == 'words':
        filter_stops = getOpt(config, sectionName,
                              'filter_stops', default=True, typ='bool')
        filter_punct = getOpt(config, sectionName,
                              'filter_punct', default=True, typ='bool')
        filter_nums = getOpt(config, sectionName,
                             'filter_punct', default=False, typ='bool')
        return lambda d: word_extractor(d, filter_stops=filter_stops, filter_punct=filter_punct, filter_nums=filter_nums)


def da_extractor(corpuses, extractor):
    result = []
    for corpus in corpuses:
        for c in corpus:
            r = [i for i in extractor(c)]
            if r:
                result.append(r)
    return result


def extractTokens(doc, pos=[]):
    tokens = [(token, str(token.lemma_), str(token.pos_))  for token in doc if not pos or token.pos_ in pos]
    return pd.DataFrame(tokens, columns=['Token', 'Lemma(root word)', 'Part-of-Speech(POS)'])

def extractNE(doc, ne=[]):
    entities = [[ent.text, ent[0].ent_type_] for ent in doc.ents if not ne or ent[0].ent_type_ in ne]
    return pd.DataFrame(entities, columns=['Named Entity', 'NE Type'])


def extractSentences(doc):
    return [s for s in doc.sents]


def handleOVR(doc, ngrams, r):
    if r == OVR.ALL:
        return ngrams
    ngrams_ = []
    i = 0
    l = len(ngrams)
    temp = []
    overlap = False
    while i < l:
        if i + 1 < l:
            overlap = ngrams[i][-1].i >= ngrams[i + 1][0].i
        if overlap:
            temp.append(ngrams[i])
            i = i + 1
            overlap = False
            continue
        temp.append(ngrams[i])
        if r == OVR.FIRST:
            ngrams_.append(temp[0])
        elif r == OVR.LAST:
            ngrams_.append(temp[-1])
        elif r == OVR.COMBINED:
            ngrams_.append(doc[temp[0][0].i: temp[-1][-1].i + 1])
        temp = []
        overlap = False
        i = i + 1
    if temp:
        temp.append(ngrams[i - 1])
        if r == OVR.FIRST:
            ngrams_.append(temp[0])
        elif r == OVR.LAST:
            ngrams_.append(temp[-1])
        elif r == OVR.COMBINED:
            ngrams_.append(doc[temp[0][0].i: temp[-1][-1].i + 1])

    return ngrams_

keyphrase_extractor=ngram_extractor