#__author__ = "Nour Omar"
#__version__ = "1.0"
#__email__ = "nour.omar@verizon.com"
#__status__ = "Production"

import spacy
nlp = spacy.load('en')
import re
import logging
logger = logging.getLogger(__name__)


def preprocess(text):

    txt = text
    if txt:
        #txt = re.sub(r'(\?|\!|\.)([^\s])', r'\1 \2', txt)
        #txt = re.sub(r'(\?|\!|\.)([\.]+)', r'\1 ', txt)
        #txt = re.sub("amp;", '', txt)
        #txt = re.sub("nl;", '', txt)
        txt = re.sub('\u0027t',"'", txt)
        txt = re.sub("n't", 'nt', txt)
 
    return txt


def remove_hash(c):
    return re.sub(r'[#|@](\w+)', '', c)


def getDoc(text,parse=False):
   # txt = text.decode('utf-8').strip()
    txt = preprocess(text)
    txt = unicode(txt)
    doc = nlp(txt, parse=parse)
    return doc
