#__author__ = "Nour Omar"
#__version__ = "1.0"
#__status__ = "Production"

from __future__ import absolute_import, division, print_function, unicode_literals
import os
import pandas as pd
import numpy as np
import spacy
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import CountVectorizer
import re
import operator
from collections import Counter, defaultdict
from decimal import Decimal
import itertools
import math
from operator import itemgetter
import itertools as it
import logging
from sklearn.decomposition import NMF, LatentDirichletAllocation, TruncatedSVD
from vzta.feature_extractors import makeExtractor, da_extractor,OVR,ner_extractor
from vzta.util import *
from vzta.corpus import Corpus
logger = logging.getLogger(__name__)


def  NER(config, sectionName):
    items = config.items(sectionName)
    logger.info("running ner_num with configuration: " + str(items))

    path = getOpt(config, sectionName, 'path')
    if not path:
        raise Exception(
            "path field has to be defined in section [" + sectionName + "]")
    has_header = getOpt(config, sectionName, 'has_header',
                        default=True, typ='bool')
    text_col = getOpt(config, sectionName, 'text_col', default=0, typ='int')
    delimiter = getOpt(config, sectionName, 'delimiter', default=",")

    outfile_prefix = getOpt(config, sectionName,
                            'outfile_prefix', default=sectionName)
    output_dir = getOpt(config, sectionName,'output_dir', default='.')
    outfile = makeFilename(output_dir,outfile_prefix)

    
    corpus = Corpus(path, has_header=has_header,
                    delimiter=delimiter, text_col=text_col)
    files = corpus.getFileNames()
    sheets = getSheetNames(files)

    result = runNER(corpus)

    save_xls(result, sheets, outfile,index=False)

def runNER(corpus):
    result=[]
    for c in corpus:
        extractor = ner_extractor(c)
        nums =[]
        original=[]
        ner=[]
        for entry in extractor:
            original.append(entry[0])
            nums.append(entry[1])
            ner.append(entry[2])
        data = {'OriginalText': original,'Phone(s)': nums,'Entities':ner}
        dframe = pd.DataFrame(data, columns=data.keys())
        result.append(dframe)
    return result





def ngramAnalysis(config, sectionName):


    items = config.items(sectionName)
    logger.info("running ngram analysis with configuration: " + str(items))

    path = getOpt(config, sectionName, 'path')
    if not path:
        raise Exception(
            "path field has to be defined in section [" + sectionName + "]")
    has_header = getOpt(config, sectionName, 'has_header',
                        default=True, typ='bool')
    text_col = getOpt(config, sectionName, 'text_col', default=0, typ='int')
    delimiter = getOpt(config, sectionName, 'delimiter', default=",")

    min_df = getOpt(config, sectionName, 'min_df', default=2, typ='int')
    max_df = getOpt(config, sectionName, 'max_df', default=0.90, typ='float')
    n_top = getOpt(config, sectionName, 'n_top', default=1000, typ='int')
    outfile_prefix = getOpt(config, sectionName,
                            'outfile_prefix', default=sectionName)
    output_dir = getOpt(config, sectionName,'output_dir', default='.')
    outfile = makeFilename(output_dir,outfile_prefix)

    extractor = makeExtractor(config, sectionName)
    corpus = Corpus(path, has_header=has_header,
                    delimiter=delimiter, text_col=text_col)
    files = corpus.getFileNames()
    sheets = getSheetNames(files)

    logger.info(str(corpus))
    result = runNGA(corpus, extractor, min_df=min_df,
                    max_df=max_df, n_top=n_top)

    save_xls(result, sheets, outfile,index=False)


def runNGA(corpus, extractor, min_df=2, max_df=0.9, n_top=1000):
    result = []
    i = 0
    for c in corpus:
        print("processing corpus %s" % i)
        logger.info("processing corpus %s" % i)
        vectorizer = CountVectorizer(
            analyzer=extractor, min_df=min_df, max_df=max_df)
        dtm = vectorizer.fit_transform(c)
        d = topTerms(dtm, vectorizer.get_feature_names(),
                     cols=['terms', 'Frequency'], n=n_top)
        result.append(d)
        i=i+1
    return result


def DA(config, sectionName):

    items = config.items(sectionName)
    logger.info(
        "running Discriminator analysis with configuration: " + str(items))
    file1 = getOpt(config, sectionName, 'file1')
    file2 = getOpt(config, sectionName, 'file2')
    if not file1 or not file2:
        raise Exception(
            " Discriminator Analysis requires both file1 and file2 to be defined in[" + sectionName + "]")

    has_header = getOpt(config, sectionName, 'has_header',
                        default=True, typ='bool')
    text_col = getOpt(config, sectionName, 'text_col', default=0, typ='int')
    delimiter = getOpt(config, sectionName, 'delimiter', default=",")

    delimiter = getOpt(config, sectionName, 'delimiter', default=",")

    max_terms_to_compare = getOpt(
        config, sectionName, 'max_terms_to_compare', default=10000, typ=int)
    max_terms_to_return = getOpt(
        config, sectionName, 'max_terms_to_return', default=1000, typ=int)

    corpus1 = Corpus(file1, has_header=has_header,
                     text_col=text_col, delimiter=delimiter)
    corpus2 = Corpus(file2, has_header=has_header,
                     text_col=text_col, delimiter=delimiter)
    extractor = makeExtractor(config, sectionName)

    result = runDA(corpus1, corpus2, extractor,
                   max_n_terms=max_terms_to_compare, top_n_terms=max_terms_to_return)
    outfile_prefix = getOpt(config, sectionName,'outfile_prefix', default=sectionName)
    output_dir = getOpt(config, sectionName,'output_dir', default='.')
    outfile = makeFilename(output_dir,outfile_prefix)
    sheets = ['file1', 'file2']


    save_xls(result, sheets, outfile,index=False)


def runDA(corpus1, corpus2, extractor, max_n_terms=10000, top_n_terms=1000):

    terms1 = da_extractor(corpus1, extractor)
    terms2 = da_extractor(corpus2, extractor)

    bool_array_grp1 = []
    bool_array_grp1.extend(it.repeat(True, times=len(terms1)))
    bool_array_grp1.extend(it.repeat(False, times=len(terms2)))
    terms_lists = terms1 + terms2
    if isinstance(top_n_terms, float):
        top_n_terms = top_n_terms * max_n_terms
    bool_array_grp1 = np.array(bool_array_grp1)
    bool_array_grp2 = np.invert(bool_array_grp1)

    dtm, id2term = da_vectorizer(terms_lists)



    dtm_grp1 = dtm[bool_array_grp1, :]
    n_docs_grp1 = dtm_grp1.shape[0]
    doc_freqs_grp1 = get_doc_freqs(dtm_grp1, normalized=False)
    # get doc freqs for all terms in grp2 documents
    dtm_grp2 = dtm[bool_array_grp2, :]
    n_docs_grp2 = dtm_grp2.shape[0]
    doc_freqs_grp2 = get_doc_freqs(dtm_grp2, normalized=False)

    # get terms that occur in a larger fraction of grp1 docs than grp2 docs
    term_ids_grp1 = np.where(doc_freqs_grp1 / float(n_docs_grp1) > doc_freqs_grp2 / float(n_docs_grp2))[0]


    # get terms that occur in a larger fraction of grp2 docs than grp1 docs
    term_ids_grp2 = np.where(
        doc_freqs_grp1 / float(n_docs_grp1) < doc_freqs_grp2 / float(n_docs_grp2))[0]
    # get grp1 terms doc freqs in and not-in grp1 and grp2 docs, plus marginal
    # totals
    grp1_terms_grp1_df = doc_freqs_grp1[term_ids_grp1]
    grp1_terms_grp2_df = doc_freqs_grp2[term_ids_grp1]

    # get grp2 terms doc freqs in and not-in grp2 and grp1 docs, plus marginal
    # totals
    grp2_terms_grp2_df = doc_freqs_grp2[term_ids_grp2]
    grp2_terms_grp1_df = doc_freqs_grp1[term_ids_grp2]

    # get grp1 terms likelihoods, then sort for most discriminating
    # grp1-not-grp2 terms
    grp1_terms_likelihoods = {}
    grp1_data = {}
    for idx, term_id in enumerate(term_ids_grp1):
        lh1 = calculate_likelyhood(
            grp1_terms_grp1_df[idx], n_docs_grp1, grp1_terms_grp2_df[idx], n_docs_grp2)
        if lh1>0:
            grp1_terms_likelihoods[id2term[term_id]] = lh1
            grp1_data[id2term[term_id]] = [lh1, grp1_terms_grp1_df[idx], grp1_terms_grp2_df[idx]]

    top_grp1_terms = [term for term, likelihood
                      in sorted(grp1_terms_likelihoods.items(),
                                key=operator.itemgetter(1), reverse=True)[:top_n_terms]]

    # get grp2 terms likelihoods, then sort for most discriminating
    # grp2-not-grp1 terms
    grp2_terms_likelihoods = {}
    grp2_data = {}
    for idx, term_id in enumerate(term_ids_grp2):
        lh2 = calculate_likelyhood(
            grp2_terms_grp2_df[idx], n_docs_grp2, grp2_terms_grp1_df[idx], n_docs_grp1)
        if lh2>0:
            grp2_terms_likelihoods[id2term[term_id]] = lh2
            grp2_data[id2term[term_id]] = [
                lh2, grp2_terms_grp2_df[idx], grp2_terms_grp1_df[idx], ]

    top_grp2_terms = [term for term, likelihood
                      in sorted(grp2_terms_likelihoods.items(),
                                key=operator.itemgetter(1), reverse=True)[:top_n_terms]]

    left = [{'term': t, 'likelyhood_score': grp1_data[t][0], 'df_file1':grp1_data[
        t][1], 'df_file2':grp1_data[t][2]} for t in top_grp1_terms]
    right = [{'term': t, 'likelyhood_score': grp2_data[t][0], 'df_file2':grp2_data[
        t][1], 'df_file1':grp2_data[t][2]} for t in top_grp2_terms]
    left_df = pd.DataFrame(left)
    right_df = pd.DataFrame(right)
    return [left_df, right_df]


def topic_model(config, sectionName):
    items = config.items(sectionName)
    message = "running Topic Modeling  with configuration: " + str(items)
    logger.info(message)
    print(message)
    n_topics = getOpt(config, sectionName, 'n_topics', default=10, typ='int')
    n_words = getOpt(config, sectionName, 'n_words', default=10, typ='int')
    model_name = getOpt(config, sectionName, 'model', default='nmf')

    path = getOpt(config, sectionName, 'path')
    if not path:
        raise Exception(
            "path field has to be defined in section [" + sectionName + "]")
    has_header = getOpt(config, sectionName, 'has_header',
                        default=True, typ='bool')
    text_col = getOpt(config, sectionName, 'text_col', default=0, typ='int')
    delimiter = getOpt(config, sectionName, 'delimiter', default=",")

    delimiter = getOpt(config, sectionName, 'delimiter', default=",")

    outfile_prefix = getOpt(config, sectionName,'outfile_prefix', default=sectionName)
    output_dir = getOpt(config, sectionName,'output_dir', default='.')
    outfile = makeFilename(output_dir,outfile_prefix)

    extractor = makeExtractor(config, sectionName)
    corpus = Corpus(path, has_header=has_header,
                    delimiter=delimiter, text_col=text_col)
    files = corpus.getFileNames()
    sheets = getSheetNames(files)

    logger.info(str(corpus))

    result = run_tm(corpus, extractor, model_name=model_name,
                    n_topics=n_topics,)

    save_xls(result, sheets, outfile)


def run_tm(corpus, extractor, model_name='nmf', n_topics=10, n_words=20):
    result = []
    i = 0
    for c in corpus:
        print("processing corpus %s" % i)
        logger.info("processing corpus %s" % i)
        vectorizer = TfidfVectorizer(
            analyzer=extractor, min_df=1, max_df=1.0)
        dtm = vectorizer.fit_transform(c)

        model = TM(model_name, n_topics=n_topics)
        model.fit(dtm)
        topic_matrix = model.transform(dtm)
        id2terms = vectorizer.get_feature_names()

        tweights = topic_matrix.sum(axis=0) / topic_matrix.sum(axis=0).sum()
        tweights = tweights.tolist()

        topic_name = []
        topic_words = []
        words_col_name = "Top Words "
        weight_col_name = "Topic Weight%"
        topic_col_name = "Topics"

        for tidx, top_terms in model.top_topic_terms(id2terms, top_n=n_words):
            topic_name.append(top_terms[0] + ',' + top_terms[1])
            topic_words.append(','.join(top_terms))
        data = {words_col_name: topic_words, weight_col_name: tweights}
        dframe = pd.DataFrame(data, columns=data.keys(), index=topic_name)
        dframe.index.name = topic_col_name
        dframe.sort_values(by=weight_col_name, inplace=True, ascending=False)
        dframe[weight_col_name] = dframe[
            weight_col_name].apply(lambda x: round(x * 100, 2))
        dframe = dframe[[words_col_name, weight_col_name]]
        result.append(dframe)
        i=i+1
    return result



class TM(object):
    def __init__(self, model, n_topics=10, **kwargs):
        if isinstance(model, (NMF, LatentDirichletAllocation, TruncatedSVD)):
            self.model = model
        else:
            self.init_tm(model, n_topics=n_topics, **kwargs)

    def init_tm(self, model, n_topics=10, **kwargs):
        if model == 'nmf':
            self.model = NMF(
                n_components=n_topics,
                init='nndsvd',
                alpha=kwargs.get('alpha', 0.1),
                l1_ratio=kwargs.get('l1_ratio', 0.5),
                max_iter=kwargs.get('max_iter', 200),
                random_state=kwargs.get('random_state', 1),
                shuffle=kwargs.get('shuffle', False))
        elif model == 'lda':
            self.model = LatentDirichletAllocation(
                n_topics=n_topics,
                max_iter=kwargs.get('max_iter', 10),
                random_state=kwargs.get('random_state', 1),
                learning_method=kwargs.get('learning_method', 'online'),
                learning_offset=kwargs.get('learning_offset', 10.0),
                batch_size=kwargs.get('batch_size', 128),
                n_jobs=kwargs.get('n_jobs', 1))
        elif model == 'lsa':
            self.model = TruncatedSVD(
                n_components=n_topics,
                algorithm=kwargs.get('algorithm', 'randomized'),
                n_iter=kwargs.get('n_iter', 5),
                random_state=kwargs.get('random_state', 1))
        else:
            msg = 'model "{}" invalid; must be {}'.format(      
                model, {'nmf', 'lda', 'lsa'})
            raise ValueError(msg)

    

    def fit(self, doc_term_matrix):
        self.model.fit(doc_term_matrix)

    def partial_fit(self, doc_term_matrix):
        if isinstance(self.model, LatentDirichletAllocation):
            self.model.partial_fit(doc_term_matrix)
        else:
            raise TypeError('only LatentDirichletAllocation models have partial_fit')

    def transform(self, doc_term_matrix):
        return self.model.transform(doc_term_matrix)

    @property
    def n_topics(self):
        try:
            return self.model.n_topics
        except AttributeError:
            return self.model.n_components

    def get_doc_topic_matrix(self, doc_term_matrix, normalize=True):
       
        doc_topic_matrix = self.transform(doc_term_matrix)
        if normalize is True:
            return doc_topic_matrix / np.sum(doc_topic_matrix, axis=1, keepdims=True)
        else:
            return doc_topic_matrix

    def top_topic_terms(self, id2term, topics=-1, top_n=10, weights=False):
        
        if topics == -1:
            topics = range(self.n_topics)
        elif isinstance(topics, int):
            topics = (topics,)

        for topic_idx in topics:
            topic = self.model.components_[topic_idx]
            if weights is False:
                yield (topic_idx,
                       tuple(id2term[i] for i in np.argsort(topic)[:-top_n - 1:-1]))
            else:
                yield (topic_idx,
                       tuple((id2term[i], topic[i]) for i in np.argsort(topic)[:-top_n - 1:-1]))

    def top_topic_docs(self, doc_topic_matrix,
                       topics=-1, top_n=10, weights=False):
       
        if topics == -1:
            topics = range(self.n_topics)
        elif isinstance(topics, int):
            topics = (topics,)

        for topic_idx in topics:
            top_doc_idxs = np.argsort(doc_topic_matrix[:, topic_idx])[:-top_n - 1:-1]
            if weights is False:
                yield (topic_idx,
                       tuple(doc_idx for doc_idx in top_doc_idxs))
            else:
                yield (topic_idx,
                       tuple((doc_idx, doc_topic_matrix[doc_idx, topic_idx]) for doc_idx in top_doc_idxs))

    def top_doc_topics(self, doc_topic_matrix, docs=-1, top_n=3, weights=False): 
        if docs == -1:
            docs = range(doc_topic_matrix.shape[0])
        elif isinstance(docs, int):
            docs = (docs,)

        for doc_idx in docs:
            top_topic_idxs = np.argsort(doc_topic_matrix[doc_idx, :])[:-top_n - 1:-1]
            if weights is False:
                yield (doc_idx,
                       tuple(topic_idx for topic_idx in top_topic_idxs))
            else:
                yield (doc_idx,
                       tuple((topic_idx, doc_topic_matrix[doc_idx, topic_idx]) for topic_idx in top_topic_idxs))


 
def runDA2(corpus1, corpus2, extractor, max_n_terms=10000, top_n_terms=1000):

    terms1 = da_extractor(corpus1, extractor)
    terms2 = da_extractor(corpus2, extractor)

    bool_array_grp1 = []
    bool_array_grp1.extend(it.repeat(True, times=len(terms1)))
    bool_array_grp1.extend(it.repeat(False, times=len(terms2)))
    terms_lists = terms1 + terms2
    if isinstance(top_n_terms, float):
        top_n_terms = top_n_terms * max_n_terms
    bool_array_grp1 = np.array(bool_array_grp1)
    bool_array_grp2 = np.invert(bool_array_grp1)

    dtm, id2term = da_vectorizer(terms_lists)


    alpha_grp1 = 1
    alpha_grp2 = 1
    dtm_grp1 = dtm[bool_array_grp1, :]
    n_docs_grp1 = dtm_grp1.shape[0]
    doc_freqs_grp1 = get_doc_freqs(dtm_grp1, normalized=False)
    # get doc freqs for all terms in grp2 documents
    dtm_grp2 = dtm[bool_array_grp2, :]
    n_docs_grp2 = dtm_grp2.shape[0]
    doc_freqs_grp2 = get_doc_freqs(dtm_grp2, normalized=False)

    # get terms that occur in a larger fraction of grp1 docs than grp2 docs
    term_ids_grp1 = np.where(doc_freqs_grp1 / float(n_docs_grp1) > doc_freqs_grp2 / float(n_docs_grp2))[0]


    # get terms that occur in a larger fraction of grp2 docs than grp1 docs
    term_ids_grp2 = np.where(
        doc_freqs_grp1 / float(n_docs_grp1) < doc_freqs_grp2 / float(n_docs_grp2))[0]
    # get grp1 terms doc freqs in and not-in grp1 and grp2 docs, plus marginal
    # totals
    grp1_terms_grp1_df = doc_freqs_grp1[term_ids_grp1]
    grp1_terms_grp2_df = doc_freqs_grp2[term_ids_grp1]

    # get grp2 terms doc freqs in and not-in grp2 and grp1 docs, plus marginal
    # totals
    grp2_terms_grp2_df = doc_freqs_grp2[term_ids_grp2]
    grp2_terms_grp1_df = doc_freqs_grp1[term_ids_grp2]

    # get grp1 terms likelihoods, then sort for most discriminating
    # grp1-not-grp2 terms
    grp1_terms_likelihoods = {}
    for idx, term_id in enumerate(term_ids_grp1):
        term1 = Decimal(math.factorial(grp1_terms_grp1_df[idx] + alpha_grp1 - 1)) * Decimal(math.factorial(grp1_terms_grp2_df[idx] + alpha_grp2 - 1)) / Decimal(math.factorial(grp1_terms_grp1_df[idx] + grp1_terms_grp2_df[idx] + alpha_grp1 + alpha_grp2 - 1))
        term2 = Decimal(math.factorial(n_docs_grp1 - grp1_terms_grp1_df[idx] + alpha_grp1 - 1)) * Decimal(math.factorial(n_docs_grp2 - grp1_terms_grp2_df[idx] + alpha_grp2 - 1)) / Decimal((math.factorial(n_docs_grp1 + n_docs_grp2 - grp1_terms_grp1_df[idx] - grp1_terms_grp2_df[idx] + alpha_grp1 + alpha_grp2 - 1)))
        grp1_terms_likelihoods[id2term[term_id]] = term1 * term2
    top_grp1_terms = [term for term, likelihood
                      in sorted(grp1_terms_likelihoods.items(),
                                key=itemgetter(1), reverse=True)[:top_n_terms]]

    # get grp2 terms likelihoods, then sort for most discriminating grp2-not-grp1 terms
    grp2_terms_likelihoods = {}
    for idx, term_id in enumerate(term_ids_grp2):
        term1 = Decimal(math.factorial(grp2_terms_grp2_df[idx] + alpha_grp2 - 1)) * Decimal(math.factorial(grp2_terms_grp1_df[idx] + alpha_grp1 - 1)) / Decimal(math.factorial(grp2_terms_grp2_df[idx] + grp2_terms_grp1_df[idx] + alpha_grp2 + alpha_grp1 - 1))
        term2 = Decimal(math.factorial(n_docs_grp2 - grp2_terms_grp2_df[idx] + alpha_grp2 - 1)) * Decimal(math.factorial(n_docs_grp1 - grp2_terms_grp1_df[idx] + alpha_grp1 - 1)) / Decimal((math.factorial(n_docs_grp2 + n_docs_grp1 - grp2_terms_grp2_df[idx] - grp2_terms_grp1_df[idx] + alpha_grp2 + alpha_grp1 - 1)))
        grp2_terms_likelihoods[id2term[term_id]] = term1 * term2
    top_grp2_terms = [term for term, likelihood
                      in sorted(grp2_terms_likelihoods.items(),
                                key=itemgetter(1), reverse=True)[:top_n_terms]]



    left_df = pd.DataFrame({'SDBD':top_grp1_terms})
    right_df = pd.DataFrame({'SDBA':top_grp2_terms})
    combined =pd.concat([left_df,right_df],axis=1)
    return combined
